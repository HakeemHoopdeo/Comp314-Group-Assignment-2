package assignment2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

/*
 * This class uses the Software Design Principle known as SRP - Single Responsibility Principle
 * i.e. One class will have one responsibility, for e.g., reading from a file.
 * This helps to keep our programs neater, smaller, & maintainable (easier to debug, etc.).
 */

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;

/* Format of the text file "TestData.txt":
 * The first line contains V,
 * The second line contains T,
 * The third line contains S,
 * The lines after that contains P,
 * After P, the next line will contain a "**"
 * This "**" concludes the production rules and introduces the
 * test cases for the grammar defined by G = (V, T, S, P)
 * After the test cases for the grammar G, the next line will 
 * contain a grammarDelimiter - i.e. "//" which depicts the 
 * start of a new grammar definition. 
 */ 

/*  grammarN: ArrayList<Grammar>
 *  {  G1, G2, ..., Gn  }
 */

/*  testCases: ArrayList<ArrayList<String> 
 *  G1: {  T1A, T1B, T1C,
 *  G2:    T2A, T2B, T2C, T2D, T2E,
 *  G3:    T3A, T3B, T3C, T3D,
 *  ...    
 *  Gm:    TmA, TmB, TmC, ..., Tmn  }
 */

/* This class prepares the test cases appropriately for processing */
public class PrepTestCases {
	private ArrayList<Grammar> grammarN = new ArrayList<>();  // List of grammars
	private ArrayList<ArrayList<String>> testCases = new ArrayList<>();  // List of test cases for each grammar
	
	
	public PrepTestCases() throws IOException{
		File testData = new File("TestData.txt");
		try (BufferedReader br = new BufferedReader(new FileReader(testData))) {
			int row = 0;
			LinkedHashSet<String> V = new LinkedHashSet<>();
			LinkedHashSet<Character> T = new LinkedHashSet<>();
		    char S = ' ';
		    LinkedHashMap<String,LinkedHashSet<String>> P = new LinkedHashMap<>();
		    String currentLine = "";
		    final String GRAMMARDELIMITER = "//";  // tells us when we encounter a new test case, i.e. a new grammar
		    final String TESTCASESDELIMITER = "**";  // tells us when we reach the end of our production rules
		    while ((currentLine = br.readLine()) != null)  {  // if there's more data 
		    	if (row == 0) {  // are we on Vi of Grammar Gi?
		    		String[] Vi = currentLine.split(" ");  // get Vi's
		    		for (int i = 0; i < Vi.length; i++) {
		    			V.add(Vi[i]);  // add them to V
		    		}
		    		row++;
		    	}
		    	else if (row == 1) {  // are we on Ti of grammar Gi?
		    		String[] Ti = currentLine.split(" ");  // get Ti's
		    		for (int i = 0; i < Ti.length; i++)
		    			T.add(Ti[i].charAt(0));  // add them to T
		    		row++;
		    	}
		    	else if (row == 2) {  // are we on Si of Grammar Gi?
		    		S = currentLine.charAt(0);  // add line to S
		    		row++;
		    	}
		    	else {  // we are on the production rules P on the file
		    		while (!currentLine.equals(TESTCASESDELIMITER)) {
		    			String[] Pij = currentLine.split(" ");  // i refers to the grammar #, j refers to rule # in P for grammar i
		    			String c = Pij[0];
		    			LinkedHashSet<String> RHSij = new LinkedHashSet<>();
		    			for (int i = 1; i < Pij.length; i++) 
		    				RHSij.add(Pij[i]);  // formulate rules for each c
		    			P.put(c, RHSij);  // add the rules to P
		    			currentLine = br.readLine();
		    		}
		    		Grammar Gi = new Grammar(V, T, S, P);
		    		    Gi.isSGrammar();
		    			grammarN.add(Gi);
		    			ArrayList<String> testCase = new ArrayList<>();
		    			while (!currentLine.equals(GRAMMARDELIMITER)) {
		    				currentLine = br.readLine();
		    				if (Gi.getValidSGrammar())
		    					// Only if grammar is a valid s-Grammar, should we add it's test case to a set of test cases 
		    					testCase.add(currentLine);
		    			}
		    			testCases.add(testCase);  
		    		// Reset Grammar Gi = (V, T, S, P) to nothing 
		    		V = new LinkedHashSet<>();
		    		T = new LinkedHashSet<>();
		    		S = ' ';
		    		P = new LinkedHashMap<>();
		    		row = 0;
		    	}
		    }
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/* Returns a list of grammars */
	public ArrayList<Grammar> getGrammar() { return grammarN; }
	
	/* Returns a list of testCases pertaining to each grammar */
	public ArrayList<ArrayList<String>> getTestCases() { return testCases; }
	
	/* This method overloads the toString() method to test if our data is being read correctly */
	public String toString(int Gi) {  
		String output = "";
		if(testCases.get(Gi).size() != 0) { 
			/* If the set of test cases is empty, then there are no test cases for this grammar.
			 * this only occurs if the grammar is an invalid s-Grammar. So only if valid, then display test cases */
			output = "testCases: ";
			for (int j = 0; j < testCases.get(Gi).size() - 1; j++) 
				output += "T" + (j+1) + " = \"" + testCases.get(Gi).get(j) + "\"\n"
						+ "           ";
		}
		return output;
	}
}