package assignment2;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;

public class Grammar {
	String errorMessage;  // Appropriate errorMessage for invalid s-grammars
	LinkedHashSet<String> V;  // Set of Variables
	LinkedHashSet<Character> T;  // Set of Terminal Symbols
    Character S;  // Starting Variable
    LinkedHashMap<String, LinkedHashSet<String>> P;  // Set of Production rules
    public static char StartUpperCase = 'A';  // represents lower boundary on Upper Case Characters for Variables
    public static char EndUpperCase = 'Z';  // represents upper boundary on Upper Case Characters for Variables
    boolean isValidSGrammar;  // used to keep track of whether the grammar is a valid s-grammar
    
    /* Initializes a new Grammar Object */
    public Grammar(LinkedHashSet<String> V, LinkedHashSet<Character> T, char S, LinkedHashMap<String,LinkedHashSet<String>> P) {
    	errorMessage = "";
        this.V = V;
        this.T = T;
        this.S = S;
        this.P = P;
        isValidSGrammar = true;
    }
    
    /* This class handles cases where our grammar is not a valid s-grammar */
   	class InvalidGrammarException extends Exception {
   		public InvalidGrammarException(String s) {
   			super(s);  // Initializes super constructor
   		}
   	}
    
    /* the below method determines whether the grammar is a valid s-grammar or not */
    public void isSGrammar() {
        /* "noDupVarTermPairs" and "varTermPairs" both store strings in the format of: 
         * "A,a" where A is a Variable in "V" and a is terminal symbol in "T" */
        HashSet<String> noDupVarTermPairs = new HashSet<>();
        ArrayList<String> varTermPairs = new ArrayList<>();
        String invalProd = ""; //stores the actual production that is invalid as a string
        boolean startsWithTerminal = true; //used to check if each production rule starts with a terminal symbol in T
        Iterator<Map.Entry<String, LinkedHashSet<String>>> entrySet = P.entrySet().iterator();
        while (entrySet.hasNext()) {
        	Map.Entry<String, LinkedHashSet<String>> entry = entrySet.next();
        	if (!V.contains(entry.getKey())) {
                setErrorMessage(entry.getKey() + " is the LHS of a production that is not one of the Variables in V.");
               	isValidSGrammar = false;
        	}
        }
        if (isValidSGrammar) {
        	for (String c: V){ //loop through each variable in V
        		HashSet<String> productions = P.get(c); //get the productions for the current variable "c"
        		for (String s: productions){ //loop through each string in the set of productions
        			invalProd = c + " --> " + s;
        			if (!T.contains(s.charAt(0))){
        				/* if the production rule "s" does not start with a terminal symbol in T, "startsWithTerminal" 
        				 * is set to false and break this inner loop because this is not a valid s-grammer */
        				startsWithTerminal = false;
        				break;
        			}
        			//Character C = c;
        			/* add the current variable "c" and next to it the starting terminal 
                	symbol of the production rule string "S", separated by a comma */
        			varTermPairs.add(c + s.charAt(0));
        		}
        		if (!startsWithTerminal) break; //break outer loop because this is not a valid s-grammer
        		//add all the strings of "varTermPairs" to "noDupVarTermPairs"
        		noDupVarTermPairs.addAll(varTermPairs);
        	}
        	if (!startsWithTerminal) {
        		/* this means there is a production where the the LHS does not 
        		 * start with a Terminal symbol in T, thus it is not a valid s-grammar */
        		setErrorMessage("In the production, " + invalProd + ", the RHS does not start with a Terminal symbol in T!");
        		isValidSGrammar = false;
        	}
        	else {
        		/* The hash set "noDupVarTermPairs" will not store any duplicate occurrences of each "A,a", while the "varTermPairs"
        		 * ArrayList will. This means if both had all the same strings of form "A,a" inserted into them, the size of 
        		 * "varTermPairs" should equal to the size of "noDupVarTermPairs.size", if there was only 1 occurrence of each "A,a" 
        		 * for the grammar. This means there are unique Variable-Terminal Symbol pairs("A,a") for the productions, 
        		 * and thus is a valid s-grammar */
        		for (String s: varTermPairs) {
        			if (varTermPairs.indexOf(s) != varTermPairs.lastIndexOf(s))
        				invalProd = "(" + s.charAt(0) + ", " + s.charAt(s.length() - 1) + ")";
        		}
        		if (noDupVarTermPairs.size() != varTermPairs.size()) {
        			/*if they are not equal in size, then there are duplicate Variable-Terminal Symbol pairs("A,a") for 
                	the productions and thus this is not a valid s-grammer*/
        			setErrorMessage(invalProd + " is a duplicate Variable-Terminal Symbol pair in the productions.");
        			isValidSGrammar = false;
        		}
        	}
        }
    }
    
    /* determines whether the parameter string "s" is generated by the grammar, or not, using left most derivation */
    public boolean acceptString(String s){
    	// replacer is a string that will replace the left most variable, in our current sentential form, with the appropriate production
        String replacer;
        String currVariable = S.toString(); //initialize the current variable to the start variable "S"
        String sentForm = currVariable.toString(); //our initial sentential form is "S"
        for (int i = 0; i < s.length(); i++) { //loop through each character of the input string "s"
            char symbol = s.charAt(i); //get the character at index i of the string "s"
            HashSet<String> productions = P.get(currVariable); //get and assign the productions, that the current variable has
            replacer = "";//initialize replacer
            for (String str: productions){
            	/* loop through each production in our set of productions for the current variable
                if the current character of s, i.e-"symbol", is equal to the terminal symbol, at the start of the current production rule string, "str",
                assign "str" to "replacer" and break this loop since we found our production rule that we will use*/
                if (symbol == str.charAt(0)) { 
                	replacer = str;
                	break; 
                }
            }
            if (replacer.equals("")) break; /*if we do not find a production rule while we still reading each character from "s",
            stop reading any more characters from s, i.e- break the outer most loop*/
            
            /*by the rules of left most derivation, we replace our left most variable by the production rule string
            replaceFirst string method replaces the first(left most) occurrence of a string*/
            sentForm = sentForm.replaceFirst(currVariable, replacer);
            System.out.println("\t" + S + " --> " + sentForm);//print out our current sentential form
            for (int j = 0; j < sentForm.length(); j++) {//this loop searches for the next(left most) variable in our sentential form and sets our current variable to it
                if (sentForm.charAt(j) >= StartUpperCase && sentForm.charAt(j) <= EndUpperCase) {
                	Character temp = sentForm.charAt(j);
                    currVariable = temp.toString();
                    break; //once we have found the first Upper case letter(variable), break this loop
                }
            }
        }
        if (sentForm.equals(s)) return true; //if our derived sentential form equals to our string, then our grammar generates the string "s"
        return false;//else, it does not generate the string "s"
    }

    /* This method overloads the toString() method and is used to check if our grammars are read correctly from the file */ 
    public String toString(int Gi) {
    	Gi++;
    	String grammar = "S-Grammar G" + Gi + " = (V, T, S, P) where,\n";
    	grammar += "V: { ";
    	for (String Vi: V)
    		grammar += Vi + ", ";
    	grammar = grammar.substring(0, grammar.length() - 2);
    	grammar += " }\nT: { ";
    	for (Character Ti: T) 
    		grammar += Ti + ", ";
    	grammar = grammar.substring(0, grammar.length() - 2);
    	grammar += " }\nS: " + S;
    	Iterator<Map.Entry<String, LinkedHashSet<String>>> entrySet = P.entrySet().iterator();
    	grammar += "\nP: ";
    	while (entrySet.hasNext()) {
    		Map.Entry<String, LinkedHashSet<String>> entry = entrySet.next();
    		ArrayList<String> rules = new ArrayList<>(entry.getValue());
    		grammar += entry.getKey() + " --> ";
    		for (int i = 0; i < rules.size(); i++) {
    			grammar += rules.get(i);
    			if (i != rules.size() - 1)
    				grammar += " | ";
    		}
    		grammar += "\n   ";
    	} 
    	return grammar;
    }
    
    public boolean getValidSGrammar() {
    	return isValidSGrammar;
    }
    
    public void checkValidSGrammar() throws InvalidGrammarException {
    	if(!isValidSGrammar)
    		throw new InvalidGrammarException(errorMessage);
    }
    
    public void setErrorMessage(String errorMessage) {
    	this.errorMessage = errorMessage;
    }
    
    public String getErrorMessage() { return errorMessage; }
    
    
}