package assignment2;

import java.io.IOException;
import java.util.ArrayList;


public class RunAssignment {

    public static void main(String[] args) throws IOException {
    	PrepTestCases processFile = new PrepTestCases();
    	ArrayList<Grammar> grammarN = processFile.getGrammar();
    	ArrayList<ArrayList<String>> testCases = processFile.getTestCases();
    	
    	
    	for (int i = 0; i < grammarN.size(); i++) {
    		testFile(grammarN.get(i), processFile, i);  // calls the method to display grammar correctly
    		try { 
    			grammarN.get(i).checkValidSGrammar();
				System.out.println("Grammar G" + (i+1) + " is a VALID s-Grammar!");
				System.out.println("So we will proceed to check the acceptance of the test cases:\n");
        		for (int j = 0; j < testCases.get(i).size() - 1; j++) {
        			System.out.println("For testCase T" + (j+1) + " - \"" + testCases.get(i).get(j) + "\":");//display test cases
        			if (grammarN.get(i).acceptString(testCases.get(i).get(j)))
            			System.out.println("String "+testCases.get(i).get(j)+" is accepted!\n");//if accepted by the grammar
            		else
        				System.out.println("String "+testCases.get(i).get(j)+" is NOT accepted!\n");//if not accepted by the grammar
            	}
    		}
    		catch (Grammar.InvalidGrammarException e){
    			System.out.println("Grammar G" + (i+1) + " is an Invalid s-Grammar!");
    			System.out.println("Reason: " + e.toString() + "\n");//display error message for invalid s-Grammar
    		    
    		}
    		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------");
    		System.out.println("----------------------------------------------------------------------------------------------------------------------------------------------------\n");    			
    	}
    }  	
    /* This method is used used in tandem with the overloaded toString() methods of the
     * other classes solely to test that our file is being read correctly */
    public static void testFile(Grammar Gn, PrepTestCases pF, int n) {
    	System.out.println(Gn.toString(n) + "\n" + pF.toString(n));
    }
}